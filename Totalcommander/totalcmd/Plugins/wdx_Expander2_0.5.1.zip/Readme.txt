Expander2 v0.5 - content plugin for Total Commander

Initial developers and sources:
  Original plugin by Franck Gartemann 
  Extended version by MVV

Use it to separate filename into different string (specific char separators) for sorting puprose.
If separator contain "\" then the path is also explosed.
Unlimited number of parts, limit may be changed in INI (Expander2.ini).
Accepts more than one divider at once - just separate them with pipe character (|).
To use it edit Expander2.ini file and specify divider(s) in [Main] section of this file.


This software provided "AS-IS" without warranty of any kind for non-commercial use only.


Ver 0.2:
 * Unicode and x64.

Ver 0.3:
 ! many separators in row count as one and drop now (example: ___ count as _);
 + now plugin check settings in Expander2.ini (will be created if not exists);
 + can use Unicode simbols as dividers (convert Expander2.ini to UTF8 with BOM);
 + can check parts from end of name;
 * default FieldCount raised to 20.

Ver 0.4:
 + added option From Path Only.

Ver 0.5:
 + added option CaseSensitive for diveders, enabled by default (like in previous versions):
 + for revert back old behavior (before 0.3) and get using group of symbols (word) as divider, add to Expander2.ini:
   OldStyle=1
   But this functions will be off:
   - many separators in row count as one and drop now (example: ___ count as _);
   - can check parts from end of name.

Ver 0.5.1:
 * internal changes.


---
ProgMan13, (ProgMan13@mail.ru)